#include <stdint.h>
#include <stdbool.h>
#include "inc/hw_types.h"
#include "inc/hw_memmap.h"
#include "inc/hw_gpio.h"
#include "driverlib/sysctl.h"
#include "driverlib/pin_map.h"
#include "driverlib/gpio.h"
#include "driverlib/interrupt.h"
#include "driverlib/systick.h"
#include "inc/tm4c123gh6pm.h"



//*****************************************************************************
//
//!	Following code is an example of use of Systick timer, and PWM concept
//! When either button is pressed, var 'count' increaments
//! For odd values of 'count', the leds will be on
//! Higher values of 'count' result to brighter LED intensity
//! 'count' cycles up to 15 then restarts at 0
//
//*****************************************************************************

// global variable visible in Watch window of debugger
// increments at least once per button press
#define 	LED_MASK 		0x06

// 'volatile' for varibles that can be changed by int
volatile char count = 0;// char is same as uint8_t
volatile uint64_t clock = 0;
volatile uint8_t past_Button = 0x11;
// only want to react to changes/edges, so need history to compare with



void
PortFunctionInit(void)
{
    //
    // Enable Peripheral Clocks 
    //
	//Needs unlock
	
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOF); //User input and output
	  SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOB); //Debug with AD2, also acts as delay for F's clock to stablize

	
	  HWREG(GPIO_PORTF_BASE + GPIO_O_LOCK) = GPIO_LOCK_KEY;
    HWREG(GPIO_PORTF_BASE + GPIO_O_CR) = 0x1;
    //
    // Enable pin PF4 for GPIOInput
    //
		GPIOPinTypeGPIOOutput(GPIO_PORTB_BASE, GPIO_PIN_2|GPIO_PIN_3);
	
	  GPIOPinTypeGPIOOutput(GPIO_PORTF_BASE, 0x0E);//GPIO_PIN_1-3);
    GPIOPinTypeGPIOInput(GPIO_PORTF_BASE, GPIO_PIN_0|GPIO_PIN_4);


		GPIO_PORTF_PUR_R |= (GPIO_PIN_0|GPIO_PIN_4); 

}



void Systick_Handler(void) // Note this function needs to be added to startup
{	//cycle 1/32 sec
	//Normally need to clear int trigger, but not for systick 
	
	clock ++; //Can replicate Arduino millis function if systick period 1ms
	GPIOPinWrite(GPIO_PORTB_BASE, GPIO_PIN_2, (clock&0x10)>>2);//debug pin2 cycles once per sec
	uint8_t button = GPIOPinRead(GPIO_PORTF_BASE, GPIO_PIN_0 | GPIO_PIN_4);
	if (button != past_Button){
		if (button != 0x11){
			count ++;
			//if (count == 16){count = 0;}//Bad way to range, what if we miss 16?
			//if (count > 15){count -= 16;}//Much better way to use conditional
			//if (count < 0){count += 16;}//would allow decreamenting, but count needs to be signed
			count &= 0x0F;//Best way, like covering the higher digits of your odometer
			//count %= 16;//&= method only works with ranges 2^n, modulus works for any range but does take multible clock cycles
		}
		past_Button = button;
	}

}
	


int main(void)
{
	
		//initialize the GPIO ports	
		PortFunctionInit();
		
    SysTickPeriodSet(SysCtlClockGet()/32); //32 Hz systick
    SysTickEnable(); //starts the counter
		SysTickIntEnable(); //arms the int

    //
    // Loop forever.
    // Lowest Priority
    while(1){
			//sudo pwm, cycle period constant ~256*3/16M, duty controlled by count
			if(count&1) GPIOPinWrite(GPIO_PORTF_BASE, LED_MASK,0xFF);
			// only odd counts display light, off otherwise
			if (count) SysCtlDelay(count<<8);
			// SysCtlDelay(0) will freeze the TIVA
			GPIOPinWrite(GPIO_PORTF_BASE, LED_MASK,0x00);
			if (15-count)SysCtlDelay ((15-count)<<8);

    }
}
